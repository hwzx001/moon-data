import requests
from fake_useragent import UserAgent
import pandas as pd
from pyquery import PyQuery as pq
import time
import random

def get_page(url):
    try:
        ua = UserAgent(verify_ssl=False)
        headers = {"User-Agent": ua.chrome}
        page = requests.get(url,headers=headers).text
        return page
    except:
        return None
def save_to_csv(shop_list):
    data = pd.DataFrame(shop_list)
    data.to_csv('shopistores.csv', mode='a', index=False, sep=',', header=False,encoding='utf-8')
def get_page_detail(page):
    if page!=None:
        try:
            page_data = pq(page) # 解析html文档
            data=page_data('#content-container-tbl > table > tbody').text().split('\n') #通过css选择器定位
        except:
            print('error')
        else:
            shop_lst=[]
            temp=[]
            ##	 Num  Store Address	 Title	 Alexa	 Best Selling	Country
            for i in range(len(data)):
                if (i+1)%6==0:
                    temp.append(data[i])
                    shop_lst.append(temp)
                    temp=[]
                else:
                    temp.append(data[i])
            save_to_csv(shop_lst)

if __name__ == '__main__':
    raw_url = 'https://www.shopistores.com/shopify/'
    #page_number=int(385375/30)
    page_number=166 #一共5000商品 167页
    print(page_number)
    for i in range(page_number):
        url=raw_url+str(i+1)
        try:
            page=get_page(url=url)
        except:
            break
        else:
            get_page_detail(page=page)
            print('第'+str(i+1)+'页已下载！')
            time.sleep(random.randint(1,3))




